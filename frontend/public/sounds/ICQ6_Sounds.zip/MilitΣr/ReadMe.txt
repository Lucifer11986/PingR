Die 8 Dateien nach (C:\Programme)\ICQ6\sounds\Default extrahieren und den Ordner auf schreibgesch�tzt setzen.
