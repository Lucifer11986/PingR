*** Installation ***

Ihr m�sst nur die mp3-dateien in den Ordner ICQ 6/sounds/default einf�gen(bzw ersetzen),dann einfach ICQ neustarten!


Copyright by nagl
