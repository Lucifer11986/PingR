~-~ Lord of the Weed Sounds for ICQ 6.0 ~-~

Die mp3-Dateien nach "C:\Programme\ICQ6\sounds\Default" verschieben und den Ordner auf "Schreibgesch�tzt" setzen. Dies kann man unter "Rechtsklick -> Eigenschaften". 





























Die Sounds stammen aus dem Film "Lord of the Weed - Sinnlos in Mittelerde". 

� by Lukas T.; smopt

Contact: ICQ - 366847881
         Email - l.thoele@web.de

